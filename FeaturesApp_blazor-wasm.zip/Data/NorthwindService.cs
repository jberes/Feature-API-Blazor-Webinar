using System.Net.Http.Json;

namespace FeaturesApp.Northwind
{
    public class NorthwindService
    {
        private readonly HttpClient http;

        public NorthwindService(HttpClient http)
        {
            this.http = http;
        }

        public async Task<CategoriesType[]?> GetCategories()
        {
            return await http.GetFromJsonAsync<CategoriesType[]>("/static-data/northwind-categories.json");
        }
    }
}