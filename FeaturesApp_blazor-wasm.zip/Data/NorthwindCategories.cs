//namespace FeaturesApp.Data.Northwind; // Razor won't recognize third level namespace
namespace FeaturesApp.Northwind;

public class CategoriesType
{
    public double? CategoryID { get; set; }
    public string? Description { get; set; }
    public string? Name { get; set; }
}
